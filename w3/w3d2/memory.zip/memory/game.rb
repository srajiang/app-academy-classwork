class Game

    
    
end


# guessed_pos
# Card at guessed_position
# previous_guess, initially set to nil

#play
# a loop where player gives us a guessed position
    # reveal the card at the guessed position -- system clear + render here
    # if previous guess is nil, then make prev guess point to card at Guessed position
    # if its not nil, then you can compare what prev guess points to and card at guessed position
        # if == do nothing
        # if != then 
            # hide prev_guess and hide card at guessed position 
            # make previous guess is nil
            # system clear + render


        
            
